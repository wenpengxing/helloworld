#ifndef  RB_TREE_H_
#define RB_TREE_H_

#define RED			1
#define BLACK		0
typedef int key_t;
typedef int data_t;
typedef int color_t;
typedef struct rb_node rb_node_t;
struct rb_node {
	key_t key;
	data_t data;
	color_t color;
	rb_node_t *left;
	rb_node_t *right; 
	rb_node_t *parent;
};

rb_node_t *rb_new_node(key_t key, data_t data);
static rb_node_t* rb_rotate_left(rb_node_t* node, rb_node_t* root);
static rb_node_t* rb_rotate_right(rb_node_t* node, rb_node_t* root); 
static rb_node_t* rb_search_auxiliary(key_t key, rb_node_t* root, rb_node_t** save);
rb_node_t* rb_search(key_t key, rb_node_t* root); 
rb_node_t* rb_insert(key_t key, data_t data, rb_node_t* root);
static rb_node_t* rb_insert_rebalance(rb_node_t *node, rb_node_t *root);
rb_node_t* rb_erase(key_t key, rb_node_t *root); 
static rb_node_t* rb_erase_rebalance(rb_node_t *node, rb_node_t *parent, rb_node_t *root);
#endif
